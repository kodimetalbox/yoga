def metalfever(params):
	return "https://lh3.googleusercontent.com/pw/AL9nZEXDwYv46AAMR47g0oXnipFC7vL2HhG55oQK2qysD6JDNDAwX7axMm7KpV4wYizRBMZlC53dK_EFozEtvx1X1T53AJ1v8mwOfmf4ehtglitV064zXl6rTaqE3L43vcP_XbgYNrPiJYzauMNY6-IsbEV2=s759-no"
	
def shauntrack(params):
	return "https://lh3.googleusercontent.com/pw/AL9nZEVZCn7wuJroJPoFcHzcKEGZ0ba_ht_YDy6nrwmijInSdT7GTAleW0l_i-nQWvJWwfK_dUHaI9Z7V1fSSc3Vs9FnmBmZKNQr65s3afLSQvVLT-sWLeIr_-Ip45fEMHgt-h0FGW18WSy_bxoh7V7dKAYm=w1280-h720-no"
	
def amusia(params):
	return "https://lh3.googleusercontent.com/pw/AL9nZEXxMxZmWoCuv6-J96aJjoc6QjWJkBLuK9lytS8_Xy1XPcqCwcSPMTB1pb2TdiNB4Qzi9WwOsZYctejxC4Ar2KBhByQmt-yF0QDMepr-iHFHssiM70z-Jl8c55YepVoD9aEtXvdu7lWxRGyrYqww9OMF=w575-h286-no"
	
def juancaraes(params):
	return "https://lh3.googleusercontent.com/pw/AL9nZEW1b6_EH7PquZOZEGT2622x_RF-hr_QAyDo7fMCOSzddvCFuQZLwKhS_PIzA-VD56ObdYpQthkJizeC-oHBwAZF89q_WAWVZaoxMAlxyTVY91KjF-GnCB_kWCbvzA4nH7H_zwuHxDJveJtLJoY_PzZL=s640-no"

def bass_channel(params):
	return "https://lh3.googleusercontent.com/pw/AL9nZEVmnKmgKSSX_eF1Rk89SD4YpWq519jEcu5jfU0DTFSLMIsXf3PcF_McmzWMdG8HaW46CvU6rvuzKfkHoqqk6vh1sucVl9hjYNDCTH12cPMk74khywlL5e3XPL-iNBCmf1orHCihcLdPKFLfjfZPl-6b=w918-h661-no"
	
