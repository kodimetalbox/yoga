import os, sys, base64
import xbmc, xbmcaddon
import plugintools
from logos import logos_menu_principal


setting = xbmcaddon.Addon().getSetting  ##Verifico Que Addon tiene seleccionado en Ajustes para reproducir Youtube
if setting('youtube_usar') == "0":  ##Tiene escogido el plugin Youtube
    usa_duffyou = False
else:  ##Ha escogido usar Duff You
    usa_duffyou = True

youtube = "plugin://plugin.video.youtube/playlist/MI-ID-PLAYLIST/"
duffyou = "eydhY3Rpb24nOiAnaW8xaTFJMScsICdmYW5hcnQnOiAnJywgJ2ljb24nOiAnJywgJ2lkJzogJ01JLUlELVBMQVlMSVNULycsICdsYWJlbCc6ICcnLCAncGFnZSc6IDEsICdwbG90JzogIiIsICdxdWVyeSc6ICIiLCAndGh1bWInOiAnJywgJ3RpcG8nOiAncGxheWxpc3QnfQ=="

arrayMenu = ([
            [ "YOGA BASICO 2020 PARA PRINCIPIANTES",  "PLNH7cFJ42PKi-Gziz-jaNHj-JgLWrLt0r"],
            [ "YOGA PARA PRINCIPIANTES niveles A y A+",  "PLNH7cFJ42PKglFjYhPRsfXhJTX9EW4PXq"],
            [ "Cervicales, Lumbar, Espalda - aliviar dolores",  "PLNH7cFJ42PKgzd6ZeKndUuMg62fM1hOfi"],
            [ "Programa para PRINCIPIANTES 2017",  "PLNH7cFJ42PKhXjRK_MwS5USxrlYomx8Nk"],
            [ "FLEXIBILIDAD PARA TODOS - PROGRAMMA",  "PLNH7cFJ42PKhZG_pQrWTPRrH7rEndEMsw"],
            [ "Ejercicios PRINCIPIANTES programa 2016",  "PLNH7cFJ42PKjD3lkpAtpxk3BG-crGld0u"],
            [ "ABDOMINALES en 21 DIA",  "PLNH7cFJ42PKgpTb0bOyRNkZyfrtBrkcH9"],
           # [ "",  ""],
           # [ "",  ""]
            ])
       

def playlists(params):
    logo=logos_menu_principal.logo_01(params)

    for i in range(len(arrayMenu)):
        titulo = arrayMenu[i][0]
        id_canal = arrayMenu[i][1]
        if usa_duffyou:  ##Usamos plugin Duff You
            reemplaza = base64.b64decode(duffyou.encode('utf-8')).decode('utf-8').replace("MI-ID-PLAYLIST" , id_canal)
            videos = "plugin://plugin.video.duffyou/?" + base64.b64encode(reemplaza.encode('utf-8')).decode('utf-8')
        else:  ##Usamos plugin YouTube
            videos = youtube.replace("MI-ID-PLAYLIST" , id_canal)
        
        plugintools.add_item( 
            title=titulo,
            url=videos,
            thumbnail=logo, folder=True )

