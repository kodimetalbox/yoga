# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Sourced From Online Templates And Guides
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon and Duff You
# Gracias a la librería plugintools de Jesús (www.mimediacenter.info)
# Thanks To: Google Search For This Template
# Modified: Pulse
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from logos import logos_menu_principal

addonName           = xbmcaddon.Addon().getAddonInfo("name")
addonVersion        = xbmcaddon.Addon().getAddonInfo("version")
addonId             = xbmcaddon.Addon().getAddonInfo("id")
addonPath           = xbmcaddon.Addon().getAddonInfo("path")

xbmc.executebuiltin('Container.SetViewMode(500)')

###########################################################
################ THIRD MENU - PLAYLISTS ###################
###########################################################
### PLAYLISTS OTHER STUFF ################################
def function_malova_elena(params):
    from yoga import playlists_malovaelena
    playlists_malovaelena.playlists(params) 

def function_mis_listas(params):
    from musicarelax import playlists_mislistas
    playlists_mislistas.playlists(params) 

    
###########################################################
################ SECOND MENU ##############################
###########################################################

def yoga(params):

    from logos import logos_youtube_channels
    
    logo_metalfever=logos_youtube_channels.metalfever(params)
    plugintools.add_item(action="function_malova_elena",title="MalovaElena", thumbnail=logo_metalfever, folder=True ) 

def musicarelax(params):

    from logos import logos_youtube_channels
    
    logo_metalfever=logos_youtube_channels.metalfever(params)
    plugintools.add_item(action="function_mis_listas",title="Mis listas", thumbnail=logo_metalfever, folder=True ) 
    
###########################################################
################ FUNCTION RUN() ###########################
###########################################################
def run():
    plugintools.log("docu.run")

    # Obteniendo parámetros...
    params = plugintools.get_params()


    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec(action+"(params)")

    plugintools.close_item_list()            

###########################################################
################ MAIN MENU #############################
###########################################################
def main_list(params):
    logo_01=logos_menu_principal.logo_01(params)
    logo_02=logos_menu_principal.logo_02(params)
    logo_addon=logos_menu_principal.logo_duffyou_youtube3(params)

    
    plugintools.log("docu.main_list "+repr(params))
 
    plugintools.add_item( 
        action="yoga", 
        title="Yoga",
        thumbnail=logo_01,
        folder=True ) 
 
    plugintools.add_item( 
        action="musicarelax", 
        title="Música relajante",
        thumbnail=logo_02,
        folder=True ) 
                                                             
                                                          
    plugintools.add_item( 
        action="", 
        title="You can chosse DuffYou or YouTube in Add-on Settings",
        thumbnail=logo_addon,
        folder=False )


run()
